package client;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import rmi.DBOInterface;

import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import javafx.scene.text.Font;

public class GUI3 extends Application {

    private DBOInterface dbo;

    @Override
    public void start(Stage primaryStage) {

        try {
            Registry registry = LocateRegistry.getRegistry("localhost", 1099);
            dbo = (DBOInterface) registry.lookup("DBOperations");
        } catch (Exception e) {
            System.out.println("❌ Failed to connect to RMI server: " + e.getMessage());
            return;
        }

        Label mainLb = new Label("🚗 VEHICLE RECORDS 🚗");
        mainLb.setStyle(
            "-fx-font-family: Garamond; " +
            "-fx-font-size: 36px; " +
            "-fx-font-weight: bold; " +
            "-fx-text-fill: navy;"
        );

        Label oldIdLb = new Label("Enter Old Vehicle ID (for lookup)");
        oldIdLb.setStyle("-fx-font-family: Garamond; -fx-font-size: 16px; -fx-text-fill: black;");
        TextField oldIdTf = new TextField();
        oldIdTf.setStyle("-fx-pref-width: 300px; -fx-font-size: 14px; -fx-padding: 5px;");

        Label idLb = new Label("Enter New Vehicle ID");
        idLb.setStyle("-fx-font-family: Garamond; -fx-font-size: 16px; -fx-text-fill: black;");
        TextField idTf = new TextField();
        idTf.setStyle("-fx-pref-width: 300px; -fx-font-size: 14px; -fx-padding: 5px;");

        Label makeLb = new Label("Enter Vehicle Make");
        makeLb.setStyle("-fx-font-family: Garamond; -fx-font-size: 16px; -fx-text-fill: black;");
        TextField makeTf = new TextField();
        makeTf.setStyle("-fx-pref-width: 300px; -fx-font-size: 14px; -fx-padding: 5px;");

        Label modelLb = new Label("Enter Vehicle Model");
        modelLb.setStyle("-fx-font-family: Garamond; -fx-font-size: 16px; -fx-text-fill: black;");
        TextField modelTf = new TextField();
        modelTf.setStyle("-fx-pref-width: 300px; -fx-font-size: 14px; -fx-padding: 5px;");

        Label sizeLb = new Label("Enter Engine Size");
        sizeLb.setStyle("-fx-font-family: Garamond; -fx-font-size: 16px; -fx-text-fill: black;");
        TextField sizeTf = new TextField();
        sizeTf.setStyle("-fx-pref-width: 300px; -fx-font-size: 14px; -fx-padding: 5px;");

        Label statusLb = new Label("Enter Vehicle Status");
        statusLb.setStyle("-fx-font-family: Garamond; -fx-font-size: 16px; -fx-text-fill: black;");
        TextField statusTf = new TextField();
        statusTf.setStyle("-fx-pref-width: 300px; -fx-font-size: 14px; -fx-padding: 5px;");

        Label priceLb = new Label("Enter Vehicle Price");
        priceLb.setStyle("-fx-font-family: Garamond; -fx-font-size: 16px; -fx-text-fill: black;");
        TextField priceTf = new TextField();
        priceTf.setStyle("-fx-pref-width: 300px; -fx-font-size: 14px; -fx-padding: 5px;");

        TextArea display = new TextArea();
        display.setEditable(false);
        display.setWrapText(true);
        display.setFont(Font.font("Segoe UI", 14));
        display.setPrefHeight(200);
        display.setStyle("-fx-control-inner-background: ghostwhite; -fx-border-color: gray; -fx-border-radius: 10;");

        Button updateBtn = new Button("Update");
        updateBtn.setStyle(
            "-fx-font-family: Garamond; " +
            "-fx-font-size: 18px; " +
            "-fx-font-weight: bold; " +
            "-fx-min-width: 140px; " +
            "-fx-padding: 8px 16px; " +
            "-fx-background-color: goldenrod; " +
            "-fx-text-fill: white; " +
            "-fx-background-radius: 6px;"
        );

        updateBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                String oldIdText = oldIdTf.getText().trim();
                String newIdText = idTf.getText().trim();
                String make = makeTf.getText().trim();
                String model = modelTf.getText().trim();
                String engineSizeText = sizeTf.getText().trim();
                String status = statusTf.getText().trim();
                String priceText = priceTf.getText().trim();

                if (oldIdText.isEmpty() || newIdText.isEmpty() || engineSizeText.isEmpty() || priceText.isEmpty()) {
                    display.appendText("⚠️ Error: Old ID, New ID, Engine Size, and Price must not be empty.\n\n");
                    return;
                }

                try {
                    int oldId = Integer.parseInt(oldIdText);
                    int newId = Integer.parseInt(newIdText);
                    int engineSize = Integer.parseInt(engineSizeText);
                    int price = Integer.parseInt(priceText);

                    String result = dbo.updateOperation(oldId, newId, make, model, engineSize, status, price);
                    display.appendText("✅ UPDATE RESULT: " + result + "\n");
                    display.appendText("🛠 Updated Vehicle:\n");
                    display.appendText("Old ID: " + oldId + "\nNew ID: " + newId + "\nMake: " + make +
                            "\nModel: " + model + "\nEngine Size: " + engineSize +
                            "\nStatus: " + status + "\nPrice: " + price + "\n\n");

                    oldIdTf.clear();
                    idTf.clear();
                    makeTf.clear();
                    modelTf.clear();
                    sizeTf.clear();
                    statusTf.clear();
                    priceTf.clear();

                } catch (NumberFormatException e) {
                    display.appendText("❌ Error: IDs, Engine Size, and Price must be valid numbers.\n\n");
                } catch (RemoteException ex) {
                    display.appendText("❌ RemoteException: " + ex.getMessage() + "\n\n");
                }
            }
        });

        VBox root = new VBox(12,
                mainLb, oldIdLb, oldIdTf, idLb, idTf,
                makeLb, makeTf, modelLb, modelTf,
                sizeLb, sizeTf, statusLb, statusTf,
                priceLb, priceTf, updateBtn, display
        );

        root.setAlignment(Pos.CENTER);
        root.setPadding(new Insets(30));
        root.setStyle("-fx-background-color: lightblue;");

        Scene scene = new Scene(root, 600, 700);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Vehicle Records - Update (RMI)");
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
