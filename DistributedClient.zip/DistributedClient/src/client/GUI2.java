package client;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import rmi.DBOInterface;

import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import javafx.scene.text.Font;

public class GUI2 extends Application {

    private DBOInterface dbo;

    @Override
    public void start(Stage primaryStage) {

        try {
            Registry registry = LocateRegistry.getRegistry("localhost", 1099);
            dbo = (DBOInterface) registry.lookup("DBOperations");
        } catch (Exception e) {
            System.out.println("❌ Failed to connect to RMI server: " + e.getMessage());
            return;
        }

        Label mainLb = new Label("🚗 VEHICLE RECORDS 🚗");
        mainLb.setStyle(
            "-fx-font-family: Garamond; " +
            "-fx-font-size: 36px; " +
            "-fx-font-weight: bold; " +
            "-fx-text-fill: navy;"
        );

        Label idLb = new Label("Enter Vehicle ID");
        idLb.setStyle("-fx-font-family: Garamond; -fx-font-size: 16px; -fx-text-fill: black;");
        TextField idTf = new TextField();
        idTf.setStyle("-fx-pref-width: 300px; -fx-font-size: 14px; -fx-padding: 5px; -fx-background-radius: 5px;");

        Button selectBtn = new Button("Select");
        selectBtn.setStyle(
            "-fx-font-family: Garamond; " +
            "-fx-font-size: 16px; " +
            "-fx-font-weight: bold; " +
            "-fx-min-width: 120px; " +
            "-fx-padding: 8px 16px; " +
            "-fx-background-color: royalblue; " +
            "-fx-text-fill: white; " +
            "-fx-background-radius: 6px;"
        );

        Button deleteBtn = new Button("Delete");
        deleteBtn.setStyle(
            "-fx-font-family: Garamond; " +
            "-fx-font-size: 16px; " +
            "-fx-font-weight: bold; " +
            "-fx-min-width: 120px; " +
            "-fx-padding: 8px 16px; " +
            "-fx-background-color: crimson; " +
            "-fx-text-fill: white; " +
            "-fx-background-radius: 6px;"
        );

        TextArea display = new TextArea();
        display.setEditable(false);
        display.setWrapText(true);
        display.setFont(Font.font("Segoe UI", 14));
        display.setPrefHeight(200);
        display.setStyle("-fx-control-inner-background: ghostwhite; -fx-border-color: gray; -fx-border-radius: 10;");

        selectBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                String idText = idTf.getText().trim();

                if (idText.isEmpty()) {
                    display.appendText("⚠️ Please enter a Vehicle ID to select.\n\n");
                    return;
                }

                try {
                    int id = Integer.parseInt(idText);
                    String[] result = dbo.selectOperation(id);

                    if (result != null && result.length > 0) {
                        display.appendText("✅ SELECT RESULT:\n");
                        for (String s : result) {
                            display.appendText(s + "\n");
                        }
                        display.appendText("\n");
                    } else {
                        display.appendText("❌ No vehicle record found.\n\n");
                    }

                } catch (NumberFormatException e) {
                    display.appendText("⚠️ Error: ID must be a valid number.\n\n");
                } catch (RemoteException ex) {
                    display.appendText("❌ RemoteException: " + ex.getMessage() + "\n\n");
                }
            }
        });

        deleteBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                String idText = idTf.getText().trim();

                if (idText.isEmpty()) {
                    display.appendText("⚠️ Please enter a Vehicle ID to delete.\n\n");
                    return;
                }

                try {
                    int id = Integer.parseInt(idText);
                    String result = dbo.deleteOperation(id);
                    display.appendText("✅ DELETE RESULT: " + result + "\n\n");

                } catch (NumberFormatException e) {
                    display.appendText("⚠️ Error: ID must be a valid number.\n\n");
                } catch (RemoteException ex) {
                    display.appendText("❌ RemoteException: " + ex.getMessage() + "\n\n");
                }
            }
        });

        VBox root = new VBox(15, mainLb, idLb, idTf, selectBtn, deleteBtn, display);
        root.setAlignment(Pos.CENTER);
        root.setPadding(new Insets(30));
        root.setStyle("-fx-background-color: lightblue;");

        Scene scene = new Scene(root, 600, 500);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Vehicle Records - RMI");
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
